# DO IT UP Booking Request API

The public booking request endpoint is a Google Apps Script web app used by the static website.

## Submit A Request

`POST https://script.google.com/macros/s/AKfycbxxplrcCs8k7pJRsvKSpqacASRIe7X9IzYyuXU-PmaL_Twy7XxJ62hQj0ww3PVkFird/exec`

The request creates a pending `[REQUEST]` calendar hold and emails the salon owner. The client receives a confirmation email only after the owner accepts the request.

## Conflict Behavior

Overlapping appointment requests are allowed. If a request overlaps an existing calendar event, the owner email includes a conflict warning.

## Authentication

The public booking request endpoint does not require OAuth. The owner acceptance link is tokenized and emailed to the salon owner.

